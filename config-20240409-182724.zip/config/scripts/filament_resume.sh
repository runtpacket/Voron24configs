#!/bin/sh
aplay /home/runtpacket/printer_data/config/sounds/filament_resume.wav
