#!/bin/sh
aplay /home/runtpacket/printer_data/config/sounds/printer_startup.wav

