#!/bin/sh
aplay /home/runtpacket/printer_data/config/sounds/print_start.wav
